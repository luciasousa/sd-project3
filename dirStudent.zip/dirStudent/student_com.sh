java clientSide.main.ClientStudent localhost 22150 stat 3
