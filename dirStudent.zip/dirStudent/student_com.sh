java clientSide.main.ClientStudent localhost 22150 
