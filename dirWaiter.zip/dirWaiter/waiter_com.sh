java clientSide.main.ClientWaiter localhost 22150 stat 3
